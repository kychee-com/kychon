Demo fixture for eagles: Coat Drive Photos
Replace with the final resource archive before production use.
