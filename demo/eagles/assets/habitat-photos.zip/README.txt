Demo fixture for eagles: Habitat Photos
Replace with the final resource archive before production use.
