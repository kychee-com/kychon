Demo fixture for eagles: Social Media Toolkit
Replace with the final resource archive before production use.
