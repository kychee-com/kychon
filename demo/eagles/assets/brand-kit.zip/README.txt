Demo fixture for eagles: Brand Kit
Replace with the final resource archive before production use.
